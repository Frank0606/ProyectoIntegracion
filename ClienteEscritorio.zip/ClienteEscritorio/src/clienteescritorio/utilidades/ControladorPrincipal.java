package clienteescritorio.utilidades;

public interface ControladorPrincipal<T> {
    void setDatos (T Datos);
}
