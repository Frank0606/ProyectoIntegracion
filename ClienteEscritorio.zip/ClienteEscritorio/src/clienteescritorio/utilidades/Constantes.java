package clienteescritorio.utilidades;

public class Constantes {
    
    public static final Integer ERROR_URL = 1001;
    public static final Integer ERROR_PETICION = 1002;
    public static final String URL_WS = "http://localhost:8084/TimeFast/api/";
}
